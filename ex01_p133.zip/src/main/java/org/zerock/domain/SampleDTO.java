package org.zerock.domain;

import lombok.Data;

// domain이 VO랑 같음

@Data
public class SampleDTO {
	private String name;
	private int age;
}
