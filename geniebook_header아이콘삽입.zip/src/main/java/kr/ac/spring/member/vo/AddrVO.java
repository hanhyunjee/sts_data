package kr.ac.spring.member.vo;

public class AddrVO {
	private String id;
	private String addr_num;
	private String addr_road;
	private String addr_detail;
	
	public void setId(String id) {
		this.id = id;
	}
	public String getAddr_num() {
		return addr_num;
	}
	public void setAddr_num(String addr_num) {
		this.addr_num = addr_num;
	}
	public String getAddr_road() {
		return addr_road;
	}
	public void setAddr_road(String addr_road) {
		this.addr_road = addr_road;
	}
	public String getAddr_detail() {
		return addr_detail;
	}
	public void setAddr_detail(String addr_detail) {
		this.addr_detail = addr_detail;
	}
	public String getId() {
		return id;
	}
	
	
	
}
